#import <UIKit/UIKit.h>

@interface ModMenuSubLayout : UIView

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIView *titleBackgroundView;
@property (nonatomic, strong) UIView *statsView;
@property (nonatomic, strong) UITableView *notificationsView;
@property (nonatomic, strong) UIView *settingsView;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;
- (UIImage *)gridPatternImage;
- (void)setupSubviewsWithTitle:(NSString *)title;
- (void)addPanGesture;

@end
