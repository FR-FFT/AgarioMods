#import "Settings.h"

// Declare the global variables
extern BOOL joystickEnabled;
BOOL quickDeathEnabled = NO; // Initialize the global variable

@interface Settings ()

@property (nonatomic, strong) NSArray<UIView *> *toggleButtons;

@end

@implementation Settings

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.03 green:0.03 blue:0.03 alpha:1.0];
        self.layer.cornerRadius = 10;
        self.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        self.layer.borderWidth = 3.0;
        [self setupSubviewsWithTitle:title];
        [self addPanGesture];
        [self loadSettings]; // Load saved settings
    }
    return self;
}

- (void)setupSubviewsWithTitle:(NSString *)title {
    [self setupTopBarWithTitle:title];
    [self setupContentView];
}

- (void)setupTopBarWithTitle:(NSString *)title {
    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.text = title;
    self.titleLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    self.titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.tag = 100; // Set tag to identify and update later
    [self addSubview:self.titleLabel];
    self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:10],
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [self.titleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10]
    ]];
    
    UIView *underlineView = [[UIView alloc] init];
    underlineView.backgroundColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    [self addSubview:underlineView];
    underlineView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [underlineView.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:2],
        [underlineView.centerXAnchor constraintEqualToAnchor:self.titleLabel.centerXAnchor],
        [underlineView.widthAnchor constraintEqualToAnchor:self.titleLabel.widthAnchor],
        [underlineView.heightAnchor constraintEqualToConstant:1]
    ]];
}

- (void)setupContentView {
    self.scrollView = [[UIScrollView alloc] init];
    self.scrollView.showsVerticalScrollIndicator = YES;
    self.scrollView.delegate = self;
    [self addSubview:self.scrollView];
    self.scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.scrollView.topAnchor constraintEqualToAnchor:self.topAnchor constant:36],
        [self.scrollView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [self.scrollView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
        [self.scrollView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-10]
    ]];
    
    UIView *contentView = [[UIView alloc] init];
    [self.scrollView addSubview:contentView];
    contentView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [contentView.topAnchor constraintEqualToAnchor:self.scrollView.topAnchor],
        [contentView.leadingAnchor constraintEqualToAnchor:self.scrollView.leadingAnchor],
        [contentView.trailingAnchor constraintEqualToAnchor:self.scrollView.trailingAnchor],
        [contentView.bottomAnchor constraintEqualToAnchor:self.scrollView.bottomAnchor],
        [contentView.widthAnchor constraintEqualToAnchor:self.scrollView.widthAnchor]
    ]];
    
    [self setupThemesDashboardViewWithContentView:contentView];
    [self setupOptionsMenuWithContentView:contentView];
    
    // Ensure contentView height is at least as big as scrollView
    [NSLayoutConstraint activateConstraints:@[
        [contentView.heightAnchor constraintGreaterThanOrEqualToAnchor:self.scrollView.heightAnchor]
    ]];
}

- (void)setupThemesDashboardViewWithContentView:(UIView *)contentView {
    UILabel *themesLabel = [[UILabel alloc] init];
    themesLabel.text = @"Themes";
    themesLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    themesLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:16];
    themesLabel.textAlignment = NSTextAlignmentCenter;
    [contentView addSubview:themesLabel];
    themesLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [themesLabel.topAnchor constraintEqualToAnchor:contentView.topAnchor constant:5],
        [themesLabel.centerXAnchor constraintEqualToAnchor:contentView.centerXAnchor]
    ]];
    
    self.themesDashboardView = [[UIView alloc] init];
    self.themesDashboardView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
    self.themesDashboardView.layer.borderWidth = 1;
    self.themesDashboardView.layer.cornerRadius = 10;
    [contentView addSubview:self.themesDashboardView];
    self.themesDashboardView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.themesDashboardView.topAnchor constraintEqualToAnchor:themesLabel.bottomAnchor constant:5],
        [self.themesDashboardView.leadingAnchor constraintEqualToAnchor:contentView.leadingAnchor constant:40],
        [self.themesDashboardView.trailingAnchor constraintEqualToAnchor:contentView.trailingAnchor constant:-40],
        [self.themesDashboardView.heightAnchor constraintEqualToConstant:50]
    ]];
    
    UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:@[@"Dark Mode", @"Default", @"Light Mode"]];
    segmentedControl.selectedSegmentIndex = 1;
    segmentedControl.tag = 200; // Set tag to identify and update later
    [segmentedControl addTarget:self action:@selector(segmentChanged:) forControlEvents:UIControlEventValueChanged];
    [self.themesDashboardView addSubview:segmentedControl];
    segmentedControl.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [segmentedControl.centerXAnchor constraintEqualToAnchor:self.themesDashboardView.centerXAnchor],
        [segmentedControl.centerYAnchor constraintEqualToAnchor:self.themesDashboardView.centerYAnchor],
        [segmentedControl.heightAnchor constraintEqualToConstant:30]
    ]];
    
    UIColor *lightGrey = [UIColor lightGrayColor];
    [segmentedControl setTitleTextAttributes:@{NSForegroundColorAttributeName: lightGrey, NSFontAttributeName: [UIFont fontWithName:@"Arial-BoldMT" size:14]} forState:UIControlStateNormal];
    [segmentedControl setTitleTextAttributes:@{NSForegroundColorAttributeName: [UIColor whiteColor], NSFontAttributeName: [UIFont fontWithName:@"Arial-BoldMT" size:14], NSShadowAttributeName: [self whiteGlowShadow]} forState:UIControlStateSelected];
}

- (NSShadow *)whiteGlowShadow {
    NSShadow *shadow = [[NSShadow alloc] init];
    shadow.shadowColor = [UIColor colorWithWhite:1.0 alpha:0.7];
    shadow.shadowBlurRadius = 5.0;
    shadow.shadowOffset = CGSizeMake(0, 0);
    return shadow;
}

- (void)setupOptionsMenuWithContentView:(UIView *)contentView {
    UIView *menuContainer = [[UIView alloc] init];
    menuContainer.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
    menuContainer.layer.borderWidth = 1;
    menuContainer.layer.cornerRadius = 10;
    [contentView addSubview:menuContainer];
    menuContainer.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [menuContainer.topAnchor constraintEqualToAnchor:self.themesDashboardView.bottomAnchor constant:20],
        [menuContainer.leadingAnchor constraintEqualToAnchor:contentView.leadingAnchor constant:20],
        [menuContainer.trailingAnchor constraintEqualToAnchor:contentView.trailingAnchor constant:-20],
        [menuContainer.bottomAnchor constraintEqualToAnchor:contentView.bottomAnchor constant:-20]
    ]];
    
    NSArray *menuItems = @[@"Joystick", @"Quick Death", @"Row 3", @"Row 4", @"Row 5", @"Row 6"];
    NSMutableArray *toggleButtons = [NSMutableArray array];
    UIView *lastMenuItem = nil;
    for (int i = 0; i < [menuItems count]; i++) {
        UIButton *menuItem = [UIButton buttonWithType:UIButtonTypeCustom];
        [menuItem setTitle:menuItems[i] forState:UIControlStateNormal];
        [menuItem setTitleColor:[UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0] forState:UIControlStateNormal];
        menuItem.titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:16];
        menuItem.backgroundColor = [UIColor clearColor];
        menuItem.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        menuItem.tag = i + 1;
        [menuItem addTarget:self action:@selector(menuItemTapped:) forControlEvents:UIControlEventTouchUpInside];
        [menuContainer addSubview:menuItem];
        menuItem.translatesAutoresizingMaskIntoConstraints = NO;
        [NSLayoutConstraint activateConstraints:@[
            [menuItem.leadingAnchor constraintEqualToAnchor:menuContainer.leadingAnchor constant:10],
            [menuItem.trailingAnchor constraintEqualToAnchor:menuContainer.trailingAnchor constant:-10],
            [menuItem.heightAnchor constraintEqualToConstant:42] // Increased height by 2
        ]];
        
        if (lastMenuItem) {
            [NSLayoutConstraint activateConstraints:@[
                [menuItem.topAnchor constraintEqualToAnchor:lastMenuItem.bottomAnchor constant:10]
            ]];
        } else {
            [NSLayoutConstraint activateConstraints:@[
                [menuItem.topAnchor constraintEqualToAnchor:menuContainer.topAnchor constant:10]
            ]];
        }
        
        if (i != [menuItems count] - 1) {
            UIView *separatorLine = [[UIView alloc] init];
            separatorLine.backgroundColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
            [menuContainer addSubview:separatorLine];
            separatorLine.translatesAutoresizingMaskIntoConstraints = NO;
            [NSLayoutConstraint activateConstraints:@[
                [separatorLine.leadingAnchor constraintEqualToAnchor:menuContainer.leadingAnchor constant:10],
                [separatorLine.trailingAnchor constraintEqualToAnchor:menuContainer.trailingAnchor constant:-10],
                [separatorLine.topAnchor constraintEqualToAnchor:menuItem.bottomAnchor constant:5],
                [separatorLine.heightAnchor constraintEqualToConstant:1]
            ]];
        }
        
        UIView *toggleButton = [self createToggleButton];
        toggleButton.tag = i + 100;
        [menuContainer addSubview:toggleButton];
        [toggleButtons addObject:toggleButton];
        toggleButton.translatesAutoresizingMaskIntoConstraints = NO;
        [NSLayoutConstraint activateConstraints:@[
            [toggleButton.centerYAnchor constraintEqualToAnchor:menuItem.centerYAnchor],
            [toggleButton.trailingAnchor constraintEqualToAnchor:menuContainer.trailingAnchor constant:-20],
            [toggleButton.widthAnchor constraintEqualToConstant:42], // Increased width by 2
            [toggleButton.heightAnchor constraintEqualToConstant:22] // Increased height by 2
        ]];
        
        lastMenuItem = menuItem;
    }
    
    if (lastMenuItem) {
        [NSLayoutConstraint activateConstraints:@[
            [lastMenuItem.bottomAnchor constraintEqualToAnchor:menuContainer.bottomAnchor constant:-10]
        ]];
    }
    
    self.toggleButtons = toggleButtons;
}

- (UIView *)createToggleButton {
    UIView *toggleButton = [[UIView alloc] init];
    toggleButton.backgroundColor = [UIColor blackColor]; // Changed default off color to black
    toggleButton.layer.cornerRadius = 5;
    toggleButton.layer.borderColor = [UIColor whiteColor].CGColor;
    toggleButton.layer.borderWidth = 1;
    UIView *toggleIndicator = [[UIView alloc] initWithFrame:CGRectMake(2, 2, 18, 18)];
    toggleIndicator.backgroundColor = [UIColor whiteColor];
    toggleIndicator.layer.cornerRadius = 4;
    [toggleButton addSubview:toggleIndicator];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleButtonTapped:)];
    [toggleButton addGestureRecognizer:tapGesture];
    return toggleButton;
}

- (void)toggleButtonTapped:(UITapGestureRecognizer *)gesture {
    UIView *toggleButton = gesture.view;
    UIView *toggleIndicator = toggleButton.subviews.firstObject;
    BOOL isToggledOn = (toggleIndicator.frame.origin.x == 2);
    [UIView animateWithDuration:0.3 animations:^{
        toggleIndicator.frame = isToggledOn ? CGRectMake(22, 2, 18, 18) : CGRectMake(2, 2, 18, 18);
        toggleButton.backgroundColor = isToggledOn ? [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0] : [UIColor blackColor];
    }];
    
    // Check if the first button (Joystick) is toggled
    if (toggleButton.tag == 100) {
        joystickEnabled = isToggledOn;
        if (joystickEnabled) {
            NSLog(@"Joystick functionality enabled.");
        } else {
            NSLog(@"Joystick functionality disabled.");
        }
    }
    
    // Check if the second button (Quick Death) is toggled
    if (toggleButton.tag == 101) {
        quickDeathEnabled = isToggledOn;
        if (quickDeathEnabled) {
            NSLog(@"Quick Death functionality enabled.");
        } else {
            NSLog(@"Quick Death functionality disabled.");
        }
    }
    
    [self saveSettings];
}

- (void)menuItemTapped:(UIButton *)sender {
    // Handle menu item tap here
    NSLog(@"Menu item %ld tapped", (long)sender.tag);
    [self saveSettings];
}

- (void)segmentChanged:(UISegmentedControl *)sender {
    // Handle theme changes here
    [self saveSettings];
}

- (void)addPanGesture {
    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self addGestureRecognizer:panGestureRecognizer];
}

- (void)handlePan:(UIPanGestureRecognizer *)panGestureRecognizer {
    if (panGestureRecognizer.state == UIGestureRecognizerStateBegan || panGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        UIView *subLayoutView = (UIView *)panGestureRecognizer.view;
        CGPoint translation = [panGestureRecognizer translationInView:subLayoutView.superview];
        CGPoint center = subLayoutView.center;
        center.x += translation.x;
        center.y += translation.y;
        
        if (center.x < subLayoutView.bounds.size.width / 2) {
            center.x = subLayoutView.bounds.size.width / 2;
        } else if (center.x > subLayoutView.superview.bounds.size.width - subLayoutView.bounds.size.width / 2) {
            center.x = subLayoutView.superview.bounds.size.width - subLayoutView.bounds.size.width / 2;
        }
        if (center.y < subLayoutView.bounds.size.height / 2) {
            center.y = subLayoutView.bounds.size.height / 2;
        } else if (center.y > subLayoutView.superview.bounds.size.height - subLayoutView.bounds.size.height / 2) {
            center.y = subLayoutView.superview.bounds.size.height - subLayoutView.bounds.size.height / 2;
        }
        
        subLayoutView.center = center;
        [panGestureRecognizer setTranslation:CGPointZero inView:subLayoutView.superview];
    }
}

// Save and Load settings feature

- (void)saveSettings {
    NSMutableDictionary *settings = [NSMutableDictionary dictionary];
    UISegmentedControl *segmentedControl = (UISegmentedControl *)[self.themesDashboardView viewWithTag:200];
    settings[@"selectedSegmentIndex"] = @(segmentedControl.selectedSegmentIndex); // Save the selected segment index
    for (int i = 0; i < 6; i++) { // Updated to 6 rows
        UIView *toggleButton = self.toggleButtons[i];
        UIView *toggleIndicator = toggleButton.subviews.firstObject;
        settings[[NSString stringWithFormat:@"toggleButton%d", i]] = @(toggleIndicator.frame.origin.x == 22);
    }
    [[NSUserDefaults standardUserDefaults] setObject:settings forKey:@"Settings"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)loadSettings {
    NSDictionary *settings = [[NSUserDefaults standardUserDefaults] objectForKey:@"Settings"];
    if (settings) {
        UISegmentedControl *segmentedControl = (UISegmentedControl *)[self.themesDashboardView viewWithTag:200];
        segmentedControl.selectedSegmentIndex = [settings[@"selectedSegmentIndex"] integerValue]; // Load the selected segment index
        for (int i = 0; i < 6; i++) { // Updated to 6 rows
            UIView *toggleButton = self.toggleButtons[i];
            UIView *toggleIndicator = toggleButton.subviews.firstObject;
            BOOL isOn = [settings[[NSString stringWithFormat:@"toggleButton%d", i]] boolValue];
            CGRect frame = isOn ? CGRectMake(22, 2, 18, 18) : CGRectMake(2, 2, 18, 18);
            toggleIndicator.frame = frame;
            toggleButton.backgroundColor = isOn ? [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0] : [UIColor blackColor];
            
            // Check if the first button (Joystick) was toggled
            if (toggleButton.tag == 100) {
                joystickEnabled = isOn;
            }
            
            // Check if the second button (Quick Death) was toggled
            if (toggleButton.tag == 101) {
                quickDeathEnabled = isOn;
            }
        }
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.scrollView layoutSubviews];
    self.scrollView.contentSize = self.scrollView.subviews.firstObject.bounds.size;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [scrollView layoutSubviews];
}

@end
