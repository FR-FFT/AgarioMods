#import "Buttons.h"
#import "ModMenuSubLayout.h"

@implementation Buttons

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        [self addButtonLines];
        [self addTitles];
        [self addScrollViews];
    }
    return self;
}

- (void)addButtonLines {
    CGFloat lineWidth = 2.0;
    CGFloat lineHeight = 150; // Decreased length by 2
    CGFloat xOffset = self.bounds.size.width / 3;
    
    CGFloat yOffset = 39; // Moved position up by 1
    
    UIView *leftLine = [[UIView alloc] initWithFrame:CGRectMake(xOffset - lineWidth / 2, yOffset, lineWidth, lineHeight)];
    leftLine.backgroundColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    [self addSubview:leftLine];
    
    UIView *rightLine = [[UIView alloc] initWithFrame:CGRectMake(2 * xOffset - lineWidth / 2, yOffset, lineWidth, lineHeight)];
    rightLine.backgroundColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    [self addSubview:rightLine];
}

- (void)addTitles {
    CGFloat titleHeight = 20.0;
    CGFloat yOffset = 59; // Moved titles to y-axis 59
    CGFloat xOffset = self.bounds.size.width / 3;
    
    NSArray *titles = @[@"Macro", @"Power", @"Split"];
    
    for (int i = 0; i < 3; i++) {
        UIView *titleBackgroundView = [[UIView alloc] initWithFrame:CGRectMake(i * xOffset + 20, yOffset - titleHeight, xOffset - 40, titleHeight)];
        titleBackgroundView.backgroundColor = [UIColor blackColor];
        titleBackgroundView.layer.cornerRadius = 5;
        titleBackgroundView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        titleBackgroundView.layer.borderWidth = 1.0;
        [self addSubview:titleBackgroundView];

        UILabel *titleLabel = [[UILabel alloc] initWithFrame:titleBackgroundView.bounds];
        titleLabel.text = titles[i];
        titleLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:12];
        [titleBackgroundView addSubview:titleLabel];
    }
}

- (void)addScrollViews {
    CGFloat yOffset = 59; // Adjusted value to move the scroll view higher
    CGFloat scrollViewHeight = self.bounds.size.height - yOffset - 10; // Adjusted height to ensure fit
    CGFloat xOffset = self.bounds.size.width / 3;
    
    for (int i = 0; i < 3; i++) {
        UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(i * xOffset, yOffset, xOffset, scrollViewHeight)];
        scrollView.backgroundColor = [UIColor clearColor];
        scrollView.clipsToBounds = YES; // Ensures content does not go outside the grid
        [self addSubview:scrollView];
        
        // Calculate the content size based on the number of circles
        CGFloat circleDiameter = 50.0;
        CGFloat titleHeight = 20.0;
        CGFloat spacing = 10.0; // Adjusted spacing to reduce content height
        CGFloat contentHeight = 2 * circleDiameter + 2 * titleHeight + 2 * spacing; // Reduced content height
        
        scrollView.contentSize = CGSizeMake(xOffset, contentHeight);
        
        // Adjust content view to fit within the scroll view height
        UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, xOffset, contentHeight)];
        contentView.backgroundColor = [UIColor clearColor];
        contentView.clipsToBounds = YES; // Ensure content does not go outside the content view
        [scrollView addSubview:contentView];
        
        [self addCirclesToContentView:contentView inSection:i];
    }
}

- (void)addCirclesToContentView:(UIView *)contentView inSection:(int)section {
    CGFloat circleDiameter = 50.0; // Original size of the circles
    CGFloat spacing = 10.0; // Adjusted spacing to reduce content height
    CGFloat yOffset = 4; // Moved circles down by 4
    
    for (int i = 0; i < 2; i++) {
        UIView *circleView = [[UIView alloc] initWithFrame:CGRectMake((contentView.bounds.size.width - circleDiameter) / 2, yOffset, circleDiameter, circleDiameter)];
        circleView.layer.cornerRadius = circleDiameter / 2;
        circleView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        circleView.layer.borderWidth = 2.0;
        circleView.backgroundColor = [UIColor blackColor]; // Black background behind purple outline
        circleView.tag = section * 10 + i + 1; // Set tag to identify later
        
        [contentView addSubview:circleView];
        
        yOffset += circleDiameter + spacing;
    }
}

- (void)removeButtonLines {
    for (UIView *subview in self.subviews) {
        if ([subview isKindOfClass:[UIView class]] && subview.backgroundColor == [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0]) {
            [subview removeFromSuperview];
        }
    }
}

- (void)closeSubLayout {
    self.hidden = YES;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SubLayoutCloseNotification" object:nil];
}

@end
