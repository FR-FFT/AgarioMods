#import <UIKit/UIKit.h>

@interface Updates : UIView

@property (nonatomic, strong) UILabel *titleLabel;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;
- (void)closeSubLayout;
@end
