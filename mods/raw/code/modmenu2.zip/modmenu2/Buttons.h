#import <UIKit/UIKit.h>
#import "ModMenuSubLayout.h"

@interface Buttons : UIView

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;
- (void)addButtonLines;
- (void)removeButtonLines;
- (void)closeSubLayout;
@end
