#import "Updates.h"

@implementation Updates

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.03 green:0.03 blue:0.03 alpha:1.0];
        self.layer.cornerRadius = 10;
        self.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        self.layer.borderWidth = 3.0;
        [self setupSubviewsWithTitle:title];
    }
    return self;
}

- (void)setupSubviewsWithTitle:(NSString *)title {
    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.text = title;
    self.titleLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    self.titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.tag = 100;
    [self addSubview:self.titleLabel];
    self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:10],
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [self.titleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10]
    ]];
    
    UIView *underline = [[UIView alloc] init];
    underline.backgroundColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    [self addSubview:underline];
    underline.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [underline.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:2],
        [underline.centerXAnchor constraintEqualToAnchor:self.titleLabel.centerXAnchor],
        [underline.widthAnchor constraintEqualToAnchor:self.titleLabel.widthAnchor],
        [underline.heightAnchor constraintEqualToConstant:1]
    ]];
    
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor colorWithPatternImage:[self gridPatternImage]];
    contentView.layer.cornerRadius = 10;
    contentView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
    contentView.layer.borderWidth = 1;
    [self addSubview:contentView];
    contentView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [contentView.topAnchor constraintEqualToAnchor:underline.bottomAnchor constant:10],
        [contentView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [contentView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
        [contentView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-10]
    ]];
    
    [self addUpdateEntries];
}

- (UIImage *)gridPatternImage {
    CGFloat size = 20.0;
    UIGraphicsBeginImageContext(CGSizeMake(size, size));
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetStrokeColorWithColor(context, [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor);
    CGContextSetLineWidth(context, 1.0);
    
    CGContextMoveToPoint(context, 0, size / 2);
    CGContextAddLineToPoint(context, size, size / 2);
    CGContextMoveToPoint(context, size / 2, 0);
    CGContextAddLineToPoint(context, size / 2, size);
    
    CGContextStrokePath(context);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)addUpdateEntries {
    UILabel *firstVersionLabel = [[UILabel alloc] init];
    firstVersionLabel.text = @"- First version of Raw Mod";
    firstVersionLabel.textColor = [UIColor whiteColor];
    firstVersionLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:18];
    firstVersionLabel.numberOfLines = 0;
    firstVersionLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:firstVersionLabel];
    firstVersionLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [firstVersionLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:50],
        [firstVersionLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [firstVersionLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10]
    ]];
    
    UILabel *feedbackLabel = [[UILabel alloc] init];
    feedbackLabel.text = @"For feedback and suggestions DM @Raw.io";
    feedbackLabel.textColor = [UIColor whiteColor];
    feedbackLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:18];
    feedbackLabel.numberOfLines = 0;
    feedbackLabel.textAlignment = NSTextAlignmentCenter;
    feedbackLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openInstagram)];
    [feedbackLabel addGestureRecognizer:tapGesture];
    NSMutableAttributedString *feedbackString = [[NSMutableAttributedString alloc] initWithString:feedbackLabel.text];
    NSRange rawIoRange = [feedbackLabel.text rangeOfString:@"@Raw.io"];
    [feedbackString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0] range:rawIoRange];
    [feedbackString addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:rawIoRange];
    feedbackLabel.attributedText = feedbackString;
    [self addSubview:feedbackLabel];
    feedbackLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [feedbackLabel.topAnchor constraintEqualToAnchor:firstVersionLabel.bottomAnchor constant:20],
        [feedbackLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [feedbackLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10]
    ]];
    
    UILabel *discordLabel = [[UILabel alloc] init];
    discordLabel.text = @"Join our Discord";
    discordLabel.textColor = [UIColor whiteColor];
    discordLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:21];
    discordLabel.numberOfLines = 0;
    discordLabel.textAlignment = NSTextAlignmentCenter;
    discordLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGesture2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openDiscord)];
    [discordLabel addGestureRecognizer:tapGesture2];
    NSMutableAttributedString *discordString = [[NSMutableAttributedString alloc] initWithString:discordLabel.text];
    NSRange discordRange = [discordLabel.text rangeOfString:@"Join our Discord"];
    [discordString addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0] range:discordRange];
    [discordString addAttribute:NSUnderlineStyleAttributeName value:@(NSUnderlineStyleSingle) range:discordRange];
    discordLabel.attributedText = discordString;
    [self addSubview:discordLabel];
    discordLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [discordLabel.topAnchor constraintEqualToAnchor:feedbackLabel.bottomAnchor constant:50],
        [discordLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [discordLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10]
    ]];
}

- (void)openInstagram {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://www.instagram.com/raw.io?igshid=MXEzZm84eHRwYjQxdQ=="]];
}

- (void)openDiscord {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://discord.gg/Qf225fAPnF"]];
}

- (void)closeSubLayout {
    self.hidden = YES;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SubLayoutCloseNotification" object:nil];
}

@end
