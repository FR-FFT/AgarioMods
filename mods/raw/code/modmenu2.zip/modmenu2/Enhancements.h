#import <UIKit/UIKit.h>
#import "CustomSlider.h"

@interface Enhancements : UIView <UIScrollViewDelegate, CustomSliderDelegate>

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIScrollView *carouselView;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) UIView *borderView;
@property (nonatomic, strong) UILabel *pageTitleLabel;
@property (nonatomic, strong) NSMutableArray *sliders;
@property (nonatomic, strong) NSMutableArray *valueLabels;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;

@end
