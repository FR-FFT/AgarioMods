#import <UIKit/UIKit.h>

@interface Settings : UIView <UIScrollViewDelegate>

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *themesDashboardView;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;
- (void)saveSettings;
- (void)loadSettings;

@end
