#import <UIKit/UIKit.h>
#import "ModMenuSubLayout.h"

@interface Profiles : UIView

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title;
- (void)addProfileCirclesAndSquares;
- (void)removeProfileCirclesAndSquares;
- (void)closeSubLayout;
@end
