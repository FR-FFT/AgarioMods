#import <UIKit/UIKit.h>

// Define the CustomSliderDelegate protocol
@protocol CustomSliderDelegate <NSObject>
- (void)customSlider:(id)slider didChangeValue:(CGFloat)value;
@end

@interface CustomSlider : UIControl

@property (nonatomic) float value; // Current value of the slider
@property (nonatomic) float minimumValue; // Minimum value of the slider
@property (nonatomic) float maximumValue; // Maximum value of the slider
@property (nonatomic, weak) id<CustomSliderDelegate> delegate; // Delegate to handle slider value changes

- (instancetype)initWithFrame:(CGRect)frame;
- (void)setValue:(float)value animated:(BOOL)animated;

@end
