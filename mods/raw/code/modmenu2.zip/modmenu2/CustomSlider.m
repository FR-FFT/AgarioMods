#import "CustomSlider.h"

@interface CustomSlider ()

@property (nonatomic, strong) UIView *trackView;
@property (nonatomic, strong) UIView *thumbView;

@end

@implementation CustomSlider

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    self.minimumValue = 0.0;
    self.maximumValue = 1.0;
    self.value = 0.0;

    // Track view
    self.trackView = [[UIView alloc] initWithFrame:CGRectMake(0, self.bounds.size.height / 2 - 2, self.bounds.size.width, 4)];
    self.trackView.backgroundColor = [UIColor blackColor];
    self.trackView.layer.cornerRadius = 2;
    [self addSubview:self.trackView];

    // Thumb view
    self.thumbView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 24, 24)];
    self.thumbView.backgroundColor = [UIColor purpleColor];
    self.thumbView.layer.cornerRadius = 12;
    self.thumbView.layer.borderColor = [UIColor blackColor].CGColor;
    self.thumbView.layer.borderWidth = 2;
    [self addSubview:self.thumbView];

    // Add gesture recognizer for thumb movement
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self.thumbView addGestureRecognizer:panGesture];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self updateThumbPosition];
}

- (void)setValue:(float)value {
    _value = value;
    [self updateThumbPosition];
}

- (void)setValue:(float)value animated:(BOOL)animated {
    _value = value;
    if (animated) {
        [UIView animateWithDuration:0.25 animations:^{
            [self updateThumbPosition];
        }];
    } else {
        [self updateThumbPosition];
    }
}

- (void)updateThumbPosition {
    CGFloat width = self.trackView.bounds.size.width - self.thumbView.bounds.size.width;
    CGFloat x = (self.value - self.minimumValue) / (self.maximumValue - self.minimumValue) * width;
    self.thumbView.center = CGPointMake(x + self.thumbView.bounds.size.width / 2, self.trackView.center.y);
}

- (void)handlePan:(UIPanGestureRecognizer *)gesture {
    CGPoint translation = [gesture translationInView:self];
    static CGPoint initialCenter;

    if (gesture.state == UIGestureRecognizerStateBegan) {
        initialCenter = self.thumbView.center;
    }

    CGFloat newCenterX = initialCenter.x + translation.x;
    newCenterX = MIN(MAX(newCenterX, self.thumbView.bounds.size.width / 2), self.bounds.size.width - self.thumbView.bounds.size.width / 2);
    self.thumbView.center = CGPointMake(newCenterX, initialCenter.y);

    // Update value based on new position
    CGFloat percentage = (newCenterX - self.thumbView.bounds.size.width / 2) / (self.bounds.size.width - self.thumbView.bounds.size.width);
    self.value = self.minimumValue + percentage * (self.maximumValue - self.minimumValue);

    [self sendActionsForControlEvents:UIControlEventValueChanged];
    if ([self.delegate respondsToSelector:@selector(customSlider:didChangeValue:)]) {
        [self.delegate customSlider:self didChangeValue:self.value];
    }
}

@end
