#import "Enhancements.h"

extern float aimSnapRateValue;

@implementation Enhancements

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        self.sliders = [NSMutableArray array];
        self.valueLabels = [NSMutableArray array];
        [self setupUIWithTitle:title];
        [self loadSliderValues];
    }
    return self;
}

- (void)setupUIWithTitle:(NSString *)title {
    self.backgroundColor = [UIColor clearColor];
    self.layer.cornerRadius = 10;

    [self setupTopBarWithTitle:title];
    [self setupCarousel]; // Corrected line
}

- (void)setupTopBarWithTitle:(NSString *)title {
    UIView *titleBackgroundView = [[UIView alloc] init];
    titleBackgroundView.backgroundColor = [UIColor clearColor];
    titleBackgroundView.layer.cornerRadius = 10;
    [self addSubview:titleBackgroundView];
    titleBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [titleBackgroundView.topAnchor constraintEqualToAnchor:self.topAnchor constant:3],
        [titleBackgroundView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [titleBackgroundView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
        [titleBackgroundView.heightAnchor constraintEqualToConstant:30]
    ]];

    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.text = title;
    self.titleLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    self.titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleBackgroundView addSubview:self.titleLabel];
    self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.titleLabel.centerYAnchor constraintEqualToAnchor:titleBackgroundView.centerYAnchor],
        [self.titleLabel.centerXAnchor constraintEqualToAnchor:titleBackgroundView.centerXAnchor]
    ]];

    UIButton *resetButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [resetButton setTitle:@"Reset" forState:UIControlStateNormal];
    [resetButton setTitleColor:[UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0] forState:UIControlStateNormal];
    resetButton.titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    resetButton.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
    resetButton.layer.borderWidth = 1.0;
    resetButton.layer.cornerRadius = 5;
    [resetButton addTarget:self action:@selector(resetSliders) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:resetButton];
    resetButton.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [resetButton.trailingAnchor constraintEqualToAnchor:titleBackgroundView.trailingAnchor constant:-15],
        [resetButton.centerYAnchor constraintEqualToAnchor:titleBackgroundView.centerYAnchor constant:-2], // Moved down by 10 points
        [resetButton.widthAnchor constraintEqualToConstant:60],
        [resetButton.heightAnchor constraintEqualToConstant:20] // Decreased height to make the border thinner
    ]];
}

- (void)setupCarousel {
    self.pageControl = [[UIPageControl alloc] init];
    self.pageControl.numberOfPages = 2;
    self.pageControl.currentPage = 0;
    self.pageControl.currentPageIndicatorTintColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    self.pageControl.pageIndicatorTintColor = [UIColor lightGrayColor];
    [self addSubview:self.pageControl];
    self.pageControl.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.pageControl.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-3],
        [self.pageControl.centerXAnchor constraintEqualToAnchor:self.centerXAnchor]
    ]];

    self.borderView = [[UIView alloc] init];
    self.borderView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
    self.borderView.layer.borderWidth = 2.0;
    self.borderView.layer.cornerRadius = 10;
    self.borderView.backgroundColor = [UIColor blackColor];
    [self addSubview:self.borderView];
    self.borderView.translatesAutoresizingMaskIntoConstraints = NO;

    [NSLayoutConstraint activateConstraints:@[
        [self.borderView.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:10],
        [self.borderView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [self.borderView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
        [self.borderView.bottomAnchor constraintEqualToAnchor:self.pageControl.topAnchor constant:20]
    ]];

    self.carouselView = [[UIScrollView alloc] init];
    self.carouselView.pagingEnabled = YES;
    self.carouselView.showsHorizontalScrollIndicator = NO;
    self.carouselView.delegate = self;
    [self.borderView addSubview:self.carouselView];
    self.carouselView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.carouselView.topAnchor constraintEqualToAnchor:self.borderView.topAnchor],
        [self.carouselView.leadingAnchor constraintEqualToAnchor:self.borderView.leadingAnchor],
        [self.carouselView.trailingAnchor constraintEqualToAnchor:self.borderView.trailingAnchor],
        [self.carouselView.bottomAnchor constraintEqualToAnchor:self.borderView.bottomAnchor]
    ]];

    UIView *page1 = [self createPageWithIndex:0];
    UIView *page2 = [self createPageWithIndex:1];

    [self.carouselView addSubview:page1];
    [self.carouselView addSubview:page2];

    page1.translatesAutoresizingMaskIntoConstraints = NO;
    page2.translatesAutoresizingMaskIntoConstraints = NO;

    [NSLayoutConstraint activateConstraints:@[
        [page1.topAnchor constraintEqualToAnchor:self.carouselView.topAnchor constant:12],
        [page1.bottomAnchor constraintEqualToAnchor:self.carouselView.bottomAnchor],
        [page1.widthAnchor constraintEqualToAnchor:self.borderView.widthAnchor],
        [page1.leadingAnchor constraintEqualToAnchor:self.carouselView.leadingAnchor],

        [page2.topAnchor constraintEqualToAnchor:self.carouselView.topAnchor constant:12],
        [page2.bottomAnchor constraintEqualToAnchor:self.carouselView.bottomAnchor],
        [page2.widthAnchor constraintEqualToAnchor:self.borderView.widthAnchor],
        [page2.leadingAnchor constraintEqualToAnchor:page1.trailingAnchor],
        [page2.trailingAnchor constraintEqualToAnchor:self.carouselView.trailingAnchor]
    ]];

    [self bringSubviewToFront:self.pageControl];

    self.pageTitleLabel = [[UILabel alloc] init];
    self.pageTitleLabel.text = @"Joystick";
    self.pageTitleLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    self.pageTitleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    self.pageTitleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.pageTitleLabel];
    self.pageTitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.pageTitleLabel.bottomAnchor constraintEqualToAnchor:self.borderView.topAnchor constant:19],
        [self.pageTitleLabel.centerXAnchor constraintEqualToAnchor:self.borderView.centerXAnchor]
    ]];
}

- (UIView *)createPageWithIndex:(NSInteger)index {
    UIView *pageView = [[UIView alloc] init];

    // Create three separate sections for each row
    for (int i = 0; i < 3; i++) {
        UIView *rowView = [self createRowViewWithIndex:i pageIndex:index];
        [pageView addSubview:rowView];
        rowView.translatesAutoresizingMaskIntoConstraints = NO;
        [NSLayoutConstraint activateConstraints:@[
            [rowView.topAnchor constraintEqualToAnchor:(i == 0 ? pageView.topAnchor : pageView.subviews[pageView.subviews.count - 2].bottomAnchor) constant:7],
            [rowView.leadingAnchor constraintEqualToAnchor:pageView.leadingAnchor constant:10],
            [rowView.trailingAnchor constraintEqualToAnchor:pageView.trailingAnchor constant:-10],
            [rowView.heightAnchor constraintEqualToConstant:34]
        ]];
    }

    return pageView;
}

- (UIView *)createRowViewWithIndex:(NSInteger)index pageIndex:(NSInteger)pageIndex {
    UIView *rowView = [[UIView alloc] init];
    rowView.backgroundColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.1 alpha:1.0];
    rowView.layer.cornerRadius = 5;
    rowView.layer.borderWidth = 1;
    rowView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;

    UILabel *rowLabel = [[UILabel alloc] init];
    rowLabel.text = (index == 0 && pageIndex == 0) ? @"Aim Snap Rate" : [NSString stringWithFormat:@"Row %ld", (long)(index + 1 + (pageIndex * 3))];
    rowLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    rowLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    rowLabel.textAlignment = NSTextAlignmentLeft;
    [rowView addSubview:rowLabel];
    rowLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [rowLabel.centerYAnchor constraintEqualToAnchor:rowView.centerYAnchor],
        [rowLabel.leadingAnchor constraintEqualToAnchor:rowView.leadingAnchor constant:10],
        [rowLabel.widthAnchor constraintEqualToAnchor:rowView.widthAnchor multiplier:0.3],
        [rowLabel.heightAnchor constraintEqualToConstant:24]
    ]];

    CustomSlider *slider = [[CustomSlider alloc] initWithFrame:CGRectMake(0, 0, 102, 17)];
    if (index == 0 && pageIndex == 0) { // Set custom min and max for the first slider
        slider.minimumValue = 0.50;
        slider.maximumValue = 0.80;
    } else {
        slider.minimumValue = 0.0;
        slider.maximumValue = 1.0;
    }
    slider.value = 0.0;
    slider.delegate = self;
    [rowView addSubview:slider];
    slider.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [slider.centerYAnchor constraintEqualToAnchor:rowView.centerYAnchor],
        [slider.leadingAnchor constraintEqualToAnchor:rowLabel.trailingAnchor constant:10],
        [slider.widthAnchor constraintEqualToConstant:102],
        [slider.heightAnchor constraintEqualToConstant:17]
    ]];

    UILabel *valueLabel = [[UILabel alloc] init];
    valueLabel.text = @"0.00";
    valueLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    valueLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    valueLabel.textAlignment = NSTextAlignmentCenter;
    valueLabel.backgroundColor = [UIColor blackColor];
    valueLabel.layer.cornerRadius = 5;
    valueLabel.layer.masksToBounds = YES;
    [rowView addSubview:valueLabel];
    valueLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [valueLabel.centerYAnchor constraintEqualToAnchor:rowView.centerYAnchor],
        [valueLabel.trailingAnchor constraintEqualToAnchor:rowView.trailingAnchor constant:-10],
        [valueLabel.widthAnchor constraintEqualToConstant:60],
        [valueLabel.heightAnchor constraintEqualToConstant:30]
    ]];

    [self.sliders addObject:slider];
    [self.valueLabels addObject:valueLabel];

    return rowView;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSInteger pageIndex = round(scrollView.contentOffset.x / scrollView.frame.size.width);
    self.pageControl.currentPage = pageIndex;

    [UIView transitionWithView:self.pageTitleLabel
                      duration:0.3
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        self.pageTitleLabel.text = (pageIndex == 0) ? @"Joystick" : @"Shoot";
                    } completion:nil];
}

- (void)customSlider:(CustomSlider *)slider didChangeValue:(CGFloat)value {
    NSInteger sliderIndex = [self.sliders indexOfObject:slider];
    UILabel *label = self.valueLabels[sliderIndex];
    label.text = [NSString stringWithFormat:@"%.2f", value];

    if (sliderIndex == 0) { // Assuming the first slider is for aim snap rate
        aimSnapRateValue = value;
    }

    [self saveSliderValues];
}

- (void)resetSliders {
    NSInteger pageIndex = self.pageControl.currentPage;
    for (int i = 0; i < 3; i++) {
        NSInteger sliderIndex = pageIndex * 3 + i;
        if (sliderIndex < self.sliders.count) {
            CustomSlider *slider = self.sliders[sliderIndex];
            if (sliderIndex == 0 && pageIndex == 0) { // Reset aim snap rate with custom min and max
                slider.value = 0.50;
                aimSnapRateValue = 0.50;
            } else {
                slider.value = 0.0;
            }
            UILabel *label = self.valueLabels[sliderIndex];
            label.text = [NSString stringWithFormat:@"%.2f", slider.value];
        }
    }
    [self saveSliderValues];
}

// Save slider values to NSUserDefaults
- (void)saveSliderValues {
    NSMutableArray *sliderValues = [NSMutableArray array];
    for (CustomSlider *slider in self.sliders) {
        [sliderValues addObject:@(slider.value)];
    }
    [[NSUserDefaults standardUserDefaults] setObject:sliderValues forKey:@"sliderValues"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

// Load slider values from NSUserDefaults
- (void)loadSliderValues {
    NSArray *sliderValues = [[NSUserDefaults standardUserDefaults] arrayForKey:@"sliderValues"];
    if (sliderValues) {
        for (int i = 0; i < sliderValues.count; i++) {
            CustomSlider *slider = self.sliders[i];
            slider.value = [sliderValues[i] floatValue];
            UILabel *label = self.valueLabels[i];
            label.text = [NSString stringWithFormat:@"%.2f", slider.value];
            
            if (i == 0) { // Assuming the first slider is for aim snap rate
                aimSnapRateValue = slider.value;
            }
        }
    } else {
        // Default value if NSUserDefaults is empty
        if (self.sliders.count > 0) {
            CustomSlider *firstSlider = self.sliders[0];
            firstSlider.value = 0.50;
            aimSnapRateValue = 0.50;
            UILabel *firstLabel = self.valueLabels[0];
            firstLabel.text = [NSString stringWithFormat:@"%.2f", firstSlider.value];
        }
    }
}

// Override hitTest to ensure sliders get touch events
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    for (CustomSlider *slider in self.sliders) {
        CGPoint sliderPoint = [self convertPoint:point toView:slider];
        if ([slider pointInside:sliderPoint withEvent:event]) {
            return [slider hitTest:sliderPoint withEvent:event];
        }
    }
    return [super hitTest:point withEvent:event];
}

@end
