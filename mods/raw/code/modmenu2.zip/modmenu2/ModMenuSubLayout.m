#import "ModMenuSubLayout.h"

@implementation ModMenuSubLayout

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.03 green:0.03 blue:0.03 alpha:1.0];
        self.layer.cornerRadius = 10;
        self.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        self.layer.borderWidth = 3.0;
        [self setupSubviewsWithTitle:title];
        [self addPanGesture];
    }
    return self;
}

- (void)setupSubviewsWithTitle:(NSString *)title {
    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.text = title;
    self.titleLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    self.titleLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:14];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.tag = 100; // Set tag to identify and update later
    [self addSubview:self.titleLabel];
    self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:10],
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [self.titleLabel.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10]
    ]];
    
    UIView *underlineView = [[UIView alloc] init];
    underlineView.backgroundColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0];
    [self addSubview:underlineView];
    underlineView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [underlineView.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:2],
        [underlineView.centerXAnchor constraintEqualToAnchor:self.titleLabel.centerXAnchor],
        [underlineView.widthAnchor constraintEqualToAnchor:self.titleLabel.widthAnchor],
        [underlineView.heightAnchor constraintEqualToConstant:1]
    ]];
    
    UIView *contentView = [[UIView alloc] init];
    contentView.backgroundColor = [UIColor colorWithPatternImage:[self gridPatternImage]];
    contentView.layer.cornerRadius = 10;
    contentView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
    contentView.layer.borderWidth = 1;
    [self addSubview:contentView];
    contentView.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [contentView.topAnchor constraintEqualToAnchor:underlineView.bottomAnchor constant:10],
        [contentView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:10],
        [contentView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-10],
        [contentView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-10]
    ]];
}

- (UIImage *)gridPatternImage {
    CGFloat size = 20.0;
    UIGraphicsBeginImageContext(CGSizeMake(size, size));
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetStrokeColorWithColor(context, [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor);
    CGContextSetLineWidth(context, 1.0);
    
    CGContextMoveToPoint(context, 0, size / 2);
    CGContextAddLineToPoint(context, size, size / 2);
    CGContextMoveToPoint(context, size / 2, 0);
    CGContextAddLineToPoint(context, size / 2, size);
    
    CGContextStrokePath(context);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)addPanGesture {
    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self addGestureRecognizer:panGestureRecognizer];
}

- (void)handlePan:(UIPanGestureRecognizer *)panGestureRecognizer {
    if (panGestureRecognizer.state == UIGestureRecognizerStateBegan || panGestureRecognizer.state == UIGestureRecognizerStateChanged) {
        UIView *subLayoutView = (UIView *)panGestureRecognizer.view;
        CGPoint translation = [panGestureRecognizer translationInView:subLayoutView.superview];
        CGPoint center = subLayoutView.center;
        center.x += translation.x;
        center.y += translation.y;
        
        if (center.x < subLayoutView.bounds.size.width / 2) {
            center.x = subLayoutView.bounds.size.width / 2;
        } else if (center.x > subLayoutView.superview.bounds.size.width - subLayoutView.bounds.size.width / 2) {
            center.x = subLayoutView.superview.bounds.size.width - subLayoutView.bounds.size.width / 2;
        }
        if (center.y < subLayoutView.bounds.size.height / 2) {
            center.y = subLayoutView.bounds.size.height / 2;
        } else if (center.y > subLayoutView.superview.bounds.size.height - subLayoutView.bounds.size.height / 2) {
            center.y = subLayoutView.superview.bounds.size.height - subLayoutView.bounds.size.height / 2;
        }
        
        subLayoutView.center = center;
        [panGestureRecognizer setTranslation:CGPointZero inView:subLayoutView.superview];
    }
}

@end
