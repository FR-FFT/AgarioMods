#import <objc/runtime.h>
#import "Profiles.h"
#import "ModMenuSubLayout.h"

@interface Profiles ()
@property (nonatomic, strong) UIView *currentlySelectedCircle;
@end

@implementation Profiles

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title {
    self = [super initWithFrame:frame];
    if (self) {
        // Initial setup if needed
        [self loadSelectedCircle];
    }
    return self;
}

- (void)addProfileCirclesAndSquares {
    CGFloat circleDiameter = 50.0;
    CGFloat spacing = 20.0;
    CGFloat squareSide = 20.0;
    CGFloat yOffset = 53.0; // Slightly lower by 8 values

    CGFloat totalWidth = 5 * circleDiameter + 4 * spacing;
    CGFloat xOffset = (self.bounds.size.width - totalWidth) / 2; // Center-align

    NSMutableArray<UIView *> *circles = [NSMutableArray array];
    NSMutableArray<UIView *> *squares = [NSMutableArray array];

    for (int i = 0; i < 5; i++) {
        CGFloat x = xOffset + i * (circleDiameter + spacing);
        CGFloat y = yOffset;

        UIView *circleView = [[UIView alloc] initWithFrame:CGRectMake(x, y, circleDiameter, circleDiameter)];
        circleView.layer.cornerRadius = circleDiameter / 2;
        circleView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        circleView.layer.borderWidth = 2.0;
        circleView.backgroundColor = [UIColor blackColor]; // Black background behind purple outline
        circleView.tag = i + 1; // Set tag to identify later
        circleView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(circleTapped:)];
        [circleView addGestureRecognizer:tapGesture];

        [self addSubview:circleView];
        [circles addObject:circleView];

        UIView *squareView = [[UIView alloc] initWithFrame:CGRectMake(x + (circleDiameter - squareSide) / 2, y + circleDiameter + 14, squareSide, squareSide)];
        squareView.layer.cornerRadius = 5.0;
        squareView.layer.borderColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0].CGColor;
        squareView.layer.borderWidth = 2.0;
        squareView.backgroundColor = [UIColor blackColor]; // Black background behind purple outline
        squareView.tag = (i + 1) * 10; // Set tag to identify later
        [self addSubview:squareView];
        [squares addObject:squareView];
    }

    objc_setAssociatedObject(self, @selector(circles), circles, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(self, @selector(squares), squares, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    // Bring the circles and squares to the front
    for (UIView *circleView in circles) {
        [self bringSubviewToFront:circleView];
    }
    for (UIView *squareView in squares) {
        [self bringSubviewToFront:squareView];
    }
}

- (void)removeProfileCirclesAndSquares {
    NSArray<UIView *> *circles = objc_getAssociatedObject(self, @selector(circles));
    NSArray<UIView *> *squares = objc_getAssociatedObject(self, @selector(squares));

    for (UIView *circleView in circles) {
        [circleView removeFromSuperview];
    }
    for (UIView *squareView in squares) {
        [squareView removeFromSuperview];
    }

    objc_setAssociatedObject(self, @selector(circles), nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(self, @selector(squares), nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)circleTapped:(UITapGestureRecognizer *)gesture {
    UIView *tappedCircle = gesture.view;
    UIView *squareView = [self viewWithTag:tappedCircle.tag * 10];
    UILabel *tickLabel = [squareView viewWithTag:9999];

    if (self.currentlySelectedCircle && self.currentlySelectedCircle != tappedCircle) {
        UIView *previousSquareView = [self viewWithTag:self.currentlySelectedCircle.tag * 10];
        [self removeTickFromView:previousSquareView];
    }

    if (tickLabel) {
        [self removeTickFromView:squareView];
        self.currentlySelectedCircle = nil;
        [self saveSelectedCircle:0]; // Save no selection
    } else {
        [self addTickToView:squareView];
        self.currentlySelectedCircle = tappedCircle;
        [self saveSelectedCircle:tappedCircle.tag]; // Save the selected circle
    }
}

- (void)addTickToView:(UIView *)view {
    CGFloat size = view.bounds.size.width;
    UILabel *tickLabel = [[UILabel alloc] initWithFrame:view.bounds];
    tickLabel.text = @"\u2713"; // Unicode character for tick mark
    tickLabel.textColor = [UIColor colorWithRed:0.6 green:0.4 blue:0.8 alpha:1.0]; // Purple color
    tickLabel.textAlignment = NSTextAlignmentCenter;
    tickLabel.font = [UIFont boldSystemFontOfSize:size];
    tickLabel.tag = 9999;
    [view addSubview:tickLabel];
}

- (void)removeTickFromView:(UIView *)view {
    UIView *tickLabel = [view viewWithTag:9999];
    [tickLabel removeFromSuperview];
}

- (void)saveSelectedCircle:(NSInteger)tag {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setInteger:tag forKey:@"selectedCircleTag"];
    [defaults synchronize];
}

- (void)loadSelectedCircle {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSInteger selectedTag = [defaults integerForKey:@"selectedCircleTag"];
    if (selectedTag > 0) {
        dispatch_async(dispatch_get_main_queue(), ^{
            UIView *selectedCircle = [self viewWithTag:selectedTag];
            if (selectedCircle) {
                self.currentlySelectedCircle = selectedCircle;
                UIView *squareView = [self viewWithTag:selectedTag * 10];
                [self addTickToView:squareView];
            }
        });
    }
}

- (void)closeSubLayout {
    self.hidden = YES;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"SubLayoutCloseNotification" object:nil];
}

@end
